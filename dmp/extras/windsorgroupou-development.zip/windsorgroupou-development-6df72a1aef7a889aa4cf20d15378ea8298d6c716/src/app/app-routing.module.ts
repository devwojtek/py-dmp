import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { DataSourcesComponent } from './data-sources/data-sources.component';
import { AddDataSourceComponent } from './add-data-source/add-data-source.component';
import { DataSourcesSelectComponent } from './data-sources-select/data-sources-select.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'data-sources',
    component: DataSourcesComponent
  },
  {
    path: 'add-data-source',
    component: AddDataSourceComponent
  },
  {
    path: 'data-sources-select',
    component: DataSourcesSelectComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
