import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AddDataSourceComponent } from './add-data-source/add-data-source.component';
import { DataSourcesComponent } from './data-sources/data-sources.component';
import { DataSourcesSelectComponent } from './data-sources-select/data-sources-select.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddDataSourceComponent,
    DataSourcesComponent,
    DataSourcesSelectComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
