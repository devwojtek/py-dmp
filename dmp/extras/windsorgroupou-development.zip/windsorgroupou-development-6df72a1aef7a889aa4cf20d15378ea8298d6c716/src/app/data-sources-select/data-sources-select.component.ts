import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-data-sources-select',
  templateUrl: './data-sources-select.component.html',
  styleUrls: ['./data-sources-select.component.scss']
})
export class DataSourcesSelectComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
