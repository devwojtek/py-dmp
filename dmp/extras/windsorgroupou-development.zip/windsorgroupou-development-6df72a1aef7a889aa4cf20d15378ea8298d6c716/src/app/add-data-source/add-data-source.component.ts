import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-add-data-source',
  templateUrl: './add-data-source.component.html',
  styleUrls: ['./add-data-source.component.scss']
})
export class AddDataSourceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
