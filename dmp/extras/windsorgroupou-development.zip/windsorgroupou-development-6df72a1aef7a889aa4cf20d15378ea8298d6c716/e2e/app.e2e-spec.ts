import { WindsorgroupouPage } from './app.po';

describe('windsorgroupou App', () => {
  let page: WindsorgroupouPage;

  beforeEach(() => {
    page = new WindsorgroupouPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
